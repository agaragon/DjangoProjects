class Empresa {
    constructor(nome,id,qtdNotas,qtdPend){
        this.nome = nome;
        this.id = id;
        this.qtdNotas = qtdNotas;
        this.qtdPend = qtdPend;
    }
}